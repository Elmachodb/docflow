from django.db import models
from django.contrib.auth.models import User, Group
from ckeditor.fields import RichTextField


class DocumentCategory(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class DocumentTag(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name


class DocumentTemplate(models.Model):
    name = models.CharField(max_length=200)
    content = RichTextField()

    def __str__(self):
        return self.name


DOCUMENT_TYPE_CHOICES = [
    ('html', 'HTML (внутренний текст)'),
    ('docx', 'DOCX (Microsoft Word)'),
    ('pdf', 'PDF (Adobe Acrobat)'),
    ('xlsx', 'XLSX (Excel)'),
    ('csv', 'CSV (табличный текст)'),
    ('txt', 'TXT (обычный текст)'),
]


class Document(models.Model):
    title = models.CharField(max_length=200)
    category = models.ForeignKey(DocumentCategory, on_delete=models.SET_NULL, null=True)
    tags = models.ManyToManyField(DocumentTag, blank=True)

    uploaded_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    file = models.FileField(upload_to='documents/files/', null=True, blank=True)
    content = RichTextField(blank=True, null=True)

    document_type = models.CharField(
        max_length=10, choices=DOCUMENT_TYPE_CHOICES, default='html'
    )

    # Группы, которым доступен просмотр и редактирование
    can_view = models.ManyToManyField(Group, related_name='can_view_documents', blank=True)
    can_edit = models.ManyToManyField(Group, related_name='can_edit_documents', blank=True)

    # Согласование
    needs_approval = models.BooleanField(default=False)
    approvers = models.ManyToManyField(User, related_name='documents_to_approve', blank=True)
    approved_by = models.ManyToManyField(User, related_name='approved_documents', blank=True)
    is_approved = models.BooleanField(default=False)

    def __str__(self):
        return self.title

    def check_full_approval(self):
        required = set(self.approvers.all())
        current = set(self.approved_by.all())
        return required.issubset(current)


class DocumentComment(models.Model):
    document = models.ForeignKey('Document', on_delete=models.CASCADE, related_name='comments')
    author = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'Комментарий от {self.author} — {self.created_at.strftime("%d.%m.%Y %H:%M")}'


class DocumentHistory(models.Model):
    ACTION_CHOICES = [
        ('created', 'Загружен документ'),
        ('approved', 'Документ одобрен'),
        ('commented', 'Добавлен комментарий'),
        ('edited', 'Документ отредактирован'),
        ('deleted', 'Документ удалён'),
    ]

    document = models.ForeignKey('Document', on_delete=models.CASCADE, related_name='history')
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    action = models.CharField(max_length=20, choices=ACTION_CHOICES)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.get_action_display()} — {self.timestamp.strftime("%d.%m.%Y %H:%M")} · {self.user}'