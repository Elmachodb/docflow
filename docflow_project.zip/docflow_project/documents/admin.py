from django.contrib import admin
from .models import Document, DocumentCategory, DocumentTag, DocumentTemplate

admin.site.register(Document)
admin.site.register(DocumentCategory)
admin.site.register(DocumentTag)
admin.site.register(DocumentTemplate)
