from django.urls import path
from .views import *

urlpatterns = [
    path('documents/', document_list_view, name='document_list'),
    path('documents/ajax/', document_list_ajax_view, name='document_list_ajax'),
    path('documents/<int:pk>/', document_detail_view, name='document_detail'),
    path('documents/<int:pk>/approve/', approve_document, name='document_approve'),
    path('documents/<int:pk>/delete/', delete_document, name='document_delete'),
    path('documents/create/', create_document_view, name='document_create'),
    path('documents/<int:pk>/edit/', edit_document_view, name='document_edit'),
    path('profile/', profile_view, name='profile'),
    path('documents/<int:pk>/export/', export_to_gcs, name='export_to_docx'),
]
