import os
from django import template

register = template.Library()

@register.filter
def basename(value):
    return os.path.basename(value.name) if value else ''

@register.simple_tag
def querystring(request, **kwargs):
    query = request.GET.copy()
    for key, value in kwargs.items():
        query[key] = value
    return query.urlencode()
