from django import forms
from .models import Document, DocumentComment
from django.contrib.auth.models import Group, User
from django.contrib.auth.forms import PasswordChangeForm as DjangoPasswordChangeForm
from ckeditor.widgets import CKEditorWidget


class CommentForm(forms.ModelForm):
    class Meta:
        model = DocumentComment
        fields = ['text']
        widgets = {
            'text': forms.Textarea(attrs={
                'rows': 3,
                'placeholder': 'Введите комментарий...',
                'class': 'w-full p-2 border rounded'
            }),
        }
        labels = {
            'text': ''
        }



class DocumentCreateForm(forms.ModelForm):
    class Meta:
        model = Document
        fields = [
            'title', 'category', 'tags',
            'can_view', 'can_edit',
            'needs_approval', 'approvers', 'approved_by',
            'is_approved', 'document_type', 'content'
        ]
        widgets = {
            'title': forms.TextInput(attrs={
                'class': 'w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500',
                'placeholder': 'Введите название документа'
            }),
            'category': forms.Select(attrs={
                'class': 'w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500'
            }),
            'tags': forms.SelectMultiple(attrs={
                'class': 'w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 h-24',
                'placeholder': 'Выберите теги'
            }),
            'can_view': forms.SelectMultiple(attrs={
                'class': 'w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 h-24',
                'placeholder': 'Группы с правом просмотра'
            }),
            'can_edit': forms.SelectMultiple(attrs={
                'class': 'w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 h-24',
                'placeholder': 'Группы с правом редактирования'
            }),
            'approvers': forms.SelectMultiple(attrs={
                'class': 'w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 h-24',
                'placeholder': 'Одобряющие пользователи'
            }),
            'approved_by': forms.SelectMultiple(attrs={
                'class': 'w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 h-24',
                'placeholder': 'Пользователи, которые уже одобрили'
            }),
            'needs_approval': forms.CheckboxInput(attrs={
                'class': ''  # ты можешь стилизовать через внешний div в шаблоне
            }),
            'is_approved': forms.CheckboxInput(attrs={
                'class': ''
            }),
            'document_type': forms.Select(attrs={
                'class': 'w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500'
            }),
            'content': CKEditorWidget(attrs={'class': 'ckeditor'}),
        }


class ProfileUpdateForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'email']
        widgets = {
            'first_name': forms.TextInput(attrs={
                'class': 'w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-all',
                'placeholder': 'Введите имя'
            }),
            'last_name': forms.TextInput(attrs={
                'class': 'w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-all',
                'placeholder': 'Введите фамилию'
            }),
            'email': forms.EmailInput(attrs={
                'class': 'w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-all',
                'placeholder': 'Введите email'
            }),
        }

class CustomPasswordChangeForm(DjangoPasswordChangeForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Сделать все поля необязательными
        for field in self.fields.values():
            field.required = False

        # Добавить placeholder и классы
        self.fields['old_password'].widget.attrs.update({
            'class': 'w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-all',
            'placeholder': 'Введите текущий пароль'
        })
        self.fields['new_password1'].widget.attrs.update({
            'class': 'w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-all',
            'placeholder': 'Введите новый пароль'
        })
        self.fields['new_password2'].widget.attrs.update({
            'class': 'w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-primary-500 transition-all',
            'placeholder': 'Повторите новый пароль'
        })

    def clean(self):
        cleaned_data = super().clean()

        # Если все поля пустые — просто пропускаем валидацию
        if not any(cleaned_data.get(field) for field in ['old_password', 'new_password1', 'new_password2']):
            self._errors.clear()
            self.cleaned_data = {}
        else:
            # Иначе выполняем стандартную валидацию
            return super().clean()

        return cleaned_data
