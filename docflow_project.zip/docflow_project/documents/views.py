from django.contrib.auth.decorators import login_required
from django.contrib.auth import update_session_auth_hash
from .models import Document, DocumentCategory, DocumentTag, DocumentTemplate, DocumentHistory
from django.db.models import Q
from datetime import datetime
from django.http import JsonResponse
from django.template.loader import render_to_string
from django.contrib.auth import get_user_model
User = get_user_model()
from django.shortcuts import render, get_object_or_404, redirect
from django.utils import timezone
from .forms import CommentForm, DocumentCreateForm, ProfileUpdateForm, CustomPasswordChangeForm



@login_required
def document_list_view(request):
    user = request.user
    documents = Document.objects.all()

    documents = documents.filter(
        Q(can_view__in=user.groups.all()) |
        Q(can_edit__in=user.groups.all()) |
        Q(uploaded_by=user)
    ).distinct()
    page_obj, paginator = paginate_documents(request, documents)

    # Поиск
    search_query = request.GET.get('search', '')
    if search_query:
        documents = documents.filter(title__icontains=search_query)

    # Фильтрация по категории
    category_id = request.GET.get('category')
    if category_id:
        documents = documents.filter(category_id=category_id)

    # ️ Фильтрация по тегам
    tag_id = request.GET.get('tag')
    if tag_id:
        documents = documents.filter(tags__id=tag_id)

    # По дате (от и до)
    date_from = request.GET.get('date_from')
    date_to = request.GET.get('date_to')
    if date_from:
        documents = documents.filter(uploaded_at__date__gte=date_from)
    if date_to:
        documents = documents.filter(uploaded_at__date__lte=date_to)

    # По автору
    author = request.GET.get('author')
    if author:
        documents = documents.filter(uploaded_by__username__icontains=author)

    # Подсчёт документов, требующих одобрения от пользователя
    needs_approval_count = Document.objects.filter(
        needs_approval=True,
        approvers=user,
    ).exclude(approved_by=user).count()

    # Категории и теги для фильтра
    categories = DocumentCategory.objects.all()
    tags = DocumentTag.objects.all()

    editable_docs = []
    viewable_docs = []

    for doc in documents:
        if request.user.groups.filter(id__in=doc.can_edit.all()).exists():
            editable_docs.append(doc.id)
        if request.user.groups.filter(id__in=doc.can_view.all()).exists():
            viewable_docs.append(doc.id)

    authors = User.objects.filter(id__in=Document.objects.values_list('uploaded_by', flat=True)).distinct()

    context = {
        'documents': documents,
        'categories': categories,
        'tags': tags,
        'search_query': search_query,
        'needs_approval_count': needs_approval_count,
        'editable_docs': editable_docs,
        'viewable_docs': viewable_docs,
        'authors': authors,
        'paginator': paginator,
        'page_obj': page_obj,
    }
    return render(request, 'document_list.html', context)


@login_required
def document_list_ajax_view(request):
    user = request.user
    documents_all = get_filtered_documents(request, user)
    page_obj, paginator = paginate_documents(request, documents_all)

    editable_docs = [doc.id for doc in page_obj if user.groups.filter(id__in=doc.can_edit.all()).exists()]
    viewable_docs = [doc.id for doc in page_obj if user.groups.filter(id__in=doc.can_view.all()).exists()]

    context = {
        'documents': page_obj,  # передаём именно текущую страницу
        'editable_docs': editable_docs,
        'viewable_docs': viewable_docs,
        'user': user,
        'paginator': paginator,
        'page_obj': page_obj,
    }

    table_html = render_to_string('_document_table.html', context)
    cards_html = render_to_string('_document_cards.html', context)

    return JsonResponse({
        'table': table_html,
        'cards': cards_html,
    })



def get_filtered_documents(request, user):
    documents = Document.objects.all()

    # Фильтрация по доступу
    documents = documents.filter(
        Q(can_view__in=user.groups.all()) |
        Q(can_edit__in=user.groups.all()) |
        Q(uploaded_by=user)
    ).distinct()

    # Поиск по названию
    search = request.GET.get('search')
    if search:
        documents = documents.filter(title__icontains=search)

    # Категория
    category = request.GET.get('category')
    if category:
        documents = documents.filter(category__id=category)

    # Тег
    tag = request.GET.get('tag')
    if tag:
        documents = documents.filter(tags__id=tag)

    # Автор
    author = request.GET.get('author')
    if author:
        documents = documents.filter(uploaded_by__username__icontains=author)

    # Дата от/до
    date_from = request.GET.get('date_from')
    if date_from:
        documents = documents.filter(uploaded_at__date__gte=date_from)

    date_to = request.GET.get('date_to')
    if date_to:
        documents = documents.filter(uploaded_at__date__lte=date_to)

    # Статус
    status = request.GET.get('status')
    if status == 'new':
        documents = documents.filter(needs_approval=False, is_approved=False)
    elif status == 'approval':
        documents = documents.filter(needs_approval=True, approvers=user).exclude(approved_by=user)
    elif status == 'waiting':
        documents = documents.filter(needs_approval=True).exclude(is_approved=True)
    elif status == 'approved':
        documents = documents.filter(is_approved=True)
    elif status == 'draft':
        documents = documents.filter(needs_approval=False, is_approved=False)

    # Только мои документы (для согласования)
    only_mine = request.GET.get('only_mine')
    if only_mine:
        documents = documents.filter(needs_approval=True, approvers=user).exclude(approved_by=user)

    return documents

from django.core.paginator import Paginator

def paginate_documents(request, documents, per_page=5):
    paginator = Paginator(documents, per_page)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return page_obj, paginator

@login_required
def document_detail_view(request, pk):
    document = get_object_or_404(Document, pk=pk)
    comments = document.comments.select_related('author').order_by('-created_at')
    history = document.history.select_related('user').order_by('-timestamp')

    can_edit = request.user.groups.filter(id__in=document.can_edit.all()).exists()
    can_view = request.user.groups.filter(id__in=document.can_view.all()).exists()
    is_creator = document.uploaded_by == request.user

    # Комментарии
    comment_form = CommentForm(request.POST or None)
    if request.method == 'POST' and 'add_comment' in request.POST:
        if comment_form.is_valid():
            new_comment = comment_form.save(commit=False)
            new_comment.document = document
            new_comment.author = request.user
            new_comment.save()
            DocumentHistory.objects.create(
                document=document,
                user=request.user,
                action='commented'
            )
            return redirect('document_detail', pk=pk)

    # Согласование: кто одобрил, кто ещё нет
    approved_users = document.approved_by.all()
    pending_users = document.approvers.exclude(id__in=approved_users)

    context = {
        'document': document,
        'comments': comments,
        'history': history,
        'approved_users': approved_users,
        'pending_users': pending_users,
        'can_edit': can_edit,
        'can_view': can_view,
        'is_creator': is_creator,
        'comment_form': comment_form,
    }
    return render(request, 'document_detail.html', context)


@login_required
def approve_document(request, pk):
    document = get_object_or_404(Document, pk=pk)
    if request.user in document.approvers.all() and request.user not in document.approved_by.all():
        document.approved_by.add(request.user)
        DocumentHistory.objects.create(
            document=document,
            user=request.user,
            action='approved'
        )
        if set(document.approvers.all()) == set(document.approved_by.all()):
            document.is_approved = True
            document.save()
    return redirect('document_detail', pk=pk)


@login_required
def delete_document(request, pk):
    document = get_object_or_404(Document, pk=pk)
    if request.user == document.uploaded_by:
        DocumentHistory.objects.create(
            document=document,
            user=request.user,
            action='deleted'
        )
        document.delete()
    return redirect('document_list')

@login_required
def create_document_view(request):
    if request.method == 'POST':
        form = DocumentCreateForm(request.POST)
        if form.is_valid():
            document = form.save(commit=False)
            document.uploaded_by = request.user
            document.save()
            form.save_m2m()
            DocumentHistory.objects.create(
                document=document,
                user=request.user,
                action='created'
            )
            return redirect('document_detail', pk=document.pk)
    else:
        form = DocumentCreateForm()

    templates = DocumentTemplate.objects.all()
    return render(request, 'document_create.html', {
        'form': form,
        'templates': templates,
    })

@login_required
def edit_document_view(request, pk):
    document = get_object_or_404(Document, pk=pk)

    # Проверка прав (опционально)
    if not (request.user == document.uploaded_by or request.user.groups.filter(id__in=document.can_edit.all()).exists()):
        return redirect('document_list')

    if request.method == 'POST':
        form = DocumentCreateForm(request.POST, instance=document)
        if form.is_valid():
            form.save()
            DocumentHistory.objects.create(
                document=document,
                user=request.user,
                action='edited'
            )
            return redirect('document_detail', pk=document.pk)
    else:
        form = DocumentCreateForm(instance=document)

    templates = DocumentTemplate.objects.all()
    return render(request, 'document_edit.html', {
        'form': form,
        'templates': templates,
        'document': document,
    })

@login_required
def profile_view(request):
    user = request.user
    documents = Document.objects.filter(uploaded_by=user)

    if request.method == 'POST':
        profile_form = ProfileUpdateForm(request.POST, instance=user)
        password_form = CustomPasswordChangeForm(user=user, data=request.POST)

        if 'update_profile' in request.POST and profile_form.is_valid():
            profile_form.save()
        if 'change_password' in request.POST and password_form.is_valid():
            password_form.save()
            update_session_auth_hash(request, request.user)

    else:
        profile_form = ProfileUpdateForm(instance=user)
        password_form = CustomPasswordChangeForm(user=user)

    return render(request, 'profile.html', {
        'profile_form': profile_form,
        'password_form': password_form,
        'documents': documents
    })




from django.shortcuts import get_object_or_404
from django.http import JsonResponse
from google.cloud import storage
from django.conf import settings
from io import BytesIO
from docx import Document as DocxDocument
from bs4 import BeautifulSoup
from django.utils.text import slugify
from .models import Document

def export_to_gcs(request, pk):
    # 1. Получаем документ из БД
    doc = get_object_or_404(Document, pk=pk)
    html = doc.content or ''

    # 2. Преобразуем HTML → текст
    soup = BeautifulSoup(html, 'html.parser')
    text = soup.get_text(separator="\n")

    # 3. Генерация DOCX-файла в памяти
    docx = DocxDocument()
    docx.add_heading(doc.title, 0)
    docx.add_paragraph(text)

    buffer = BytesIO()
    docx.save(buffer)
    buffer.seek(0)

    # 4. Сохраняем в Google Cloud Storage
    client = storage.Client(credentials=settings.GS_CREDENTIALS, project=settings.GS_PROJECT_ID)
    bucket = client.bucket(settings.GS_BUCKET_NAME)

    # Название файла
    safe_filename = slugify(doc.title) or "document"
    filename = f"{safe_filename}.docx"
    blob_path = f'documents/{filename}'

    blob = bucket.blob(blob_path)
    blob.upload_from_file(buffer, content_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document')

    # 5. Возвращаем публичную ссылку
    public_url = blob.public_url

    return JsonResponse({
        'status': 'success',
        'url': public_url,
        'message': 'Документ успешно экспортирован в облако.'
    })



